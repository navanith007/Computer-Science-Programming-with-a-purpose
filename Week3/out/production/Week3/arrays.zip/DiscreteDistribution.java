public class DiscreteDistribution {

    public static void main(String[] args){
        int n = args.length;
        int m = Integer.parseInt(args[0]);
        int[] a = new int[n-1];
        int[] s = new int[n-1];

        for(int i=0; i<n-1; i++){
            a[i] = Integer.parseInt(args[i+1]);
        }

        for(int i=0; i<n-1; i++){
            s[i] =0;
            for(int j=0; j<=i; j++){
                s[i] = s[i] + a[j];
            }
        }

        for(int i=0; i<m; i++){
            int r = (int) (Math.random() * ( s[n-2]+1 - s[0] ) ) + s[0];
            for(int j=0; j<n-1; j++){
                if(r<s[j]){
                    System.out.print(j+1 + " ");
                    break;
                }
            }
        }

    }
}
